import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@TeleOp
public class SistemaPrincipal extends LinearOpMode {

    @Override
    public void runOpMode() throws InterruptedException {
        DcMotorEx motordisparador = hardwareMap.get(DcMotorEx.class, "motordisparador");
        DcMotorEx motorinverso = hardwareMap.get(DcMotorEx.class, "motorinverso");
        waitForStart();

        motordisparador.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        motordisparador.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motordisparador.setDirection(DcMotor.Direction.FORWARD);
        motorinverso.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        motorinverso.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorinverso.setDirection(DcMotorSimple.Direction.REVERSE);

        while (opModeIsActive()) {
            if (gamepad1.a) {
                motordisparador.setPower(1.0);
                motorinverso.setPower(1.0);
            }
            else {
                motordisparador.setPower(0.0);
                motorinverso.setPower(0.0);
            }
        }

        telemetry.addData("Poder Motor:", motordisparador.getPower());
        telemetry.addData("Poder Motor:", motorinverso.getPower());
        telemetry.update();
    }
}

