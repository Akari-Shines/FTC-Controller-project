package subsistema;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.geometry.Rotation2d;
import com.arcrobotics.ftclib.kinematics.wpilibkinematics.DifferentialDriveOdometry;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.IMU;

public class Chasis extends SubsystemBase {
    private DcMotorEx Left_DriveTrain;
    private DcMotorEx Right_DriveTrain;

    private final double CLICKS_POR_METRO = 28.0;
    private final double ANCHO_ROBOT = 0.09;
    private final double REDUCCION = 20.0;

    private DifferentialDriveOdometry differentialDriveOdometry;
    private IMU imu;
    private double leftoffset = 0.0;
    private double rightoffset = 0.0;

    public Chasis (HardwareMap hardwareMap){
        Left_DriveTrain = (DcMotorEx) hardwareMap.get(DcMotor.class, "left_drive");
        Right_DriveTrain = (DcMotorEx) hardwareMap.get(DcMotor.class, "right_drive");

        Left_DriveTrain.setDirection(DcMotorSimple.Direction.REVERSE);
        Right_DriveTrain.setDirection(DcMotorSimple.Direction.FORWARD);

        differentialDriveOdometry = new DifferentialDriveOdometry(new Rotation2d());
        imu = hardwareMap.get(IMU.class, "IMU");
        IMU.Parameters imuparameters = new IMU.Parameters(new
                RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.LEFT,
                                        RevHubOrientationOnRobot.UsbFacingDirection.UP));
    imu.initialize(imuparameters);
    imu.resetYaw();

    }
}