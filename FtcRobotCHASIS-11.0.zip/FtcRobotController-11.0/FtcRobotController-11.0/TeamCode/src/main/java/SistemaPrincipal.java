import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@TeleOp
public class SistemaPrincipal extends LinearOpMode {

    @Override
    public void runOpMode() throws InterruptedException {

        telemetry.addData();
        telemetry.update();
    }
}

